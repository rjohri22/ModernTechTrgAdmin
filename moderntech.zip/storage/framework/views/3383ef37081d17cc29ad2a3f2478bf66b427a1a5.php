
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header"><?php echo e(__('Profile')); ?></div>
				<div class="card-body">
					<div class="row">
						<div class="col-md-12">
							<div class="bs-stepper">
								<div class="bs-stepper-header" role="tablist">
									<div class="step" data-target="#logins-part">
										<button type="button" class="step-trigger" role="tab" aria-controls="logins-part" id="logins-part-trigger">
											<span class="bs-stepper-circle">1</span>
											<span class="bs-stepper-label"><?php echo e(('Information')); ?></span>
										</button>
									</div>

									<div class="line"></div>
									<div class="step" data-target="#information-part">
										<button type="button" class="step-trigger" role="tab" aria-controls="information-part" id="information-part-trigger">
											<span class="bs-stepper-circle">2</span>
											<span class="bs-stepper-label"><?php echo e(('Education')); ?></span>
										</button>
									</div>
									<div class="line"></div>
									<div class="step" data-target="#work-part">
										<button type="button" class="step-trigger" role="tab" aria-controls="work-part" id="work-part-trigger">
											<span class="bs-stepper-circle">3</span>
											<span class="bs-stepper-label"><?php echo e(('Work')); ?></span>
										</button>
									</div>
								</div>

								<div class="bs-stepper-content">
									<input type="hidden" name="user_id" value="" id="user_id" class="user_id">
									<div id="logins-part" class="content" step='1' role="tabpanel" aria-labelledby="logins-part-trigger">
										<br>
										<form id="step_1_form" enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
											<strong>User Info</strong>
											<hr>
											<div class="row">
												<div class="col-sm-4">
													<div class="form-group">
														<label><?php echo e(('Profile Image')); ?></label>
														<img src="https://www.simplilearn.com/ice9/free_resources_article_thumb/what_is_image_Processing.jpg" style="width: 100%">
														<br>
														<br>
														<input type="file" name="profile_url" id="profile_image" class="form-control profile_image">
														<input type="hidden" name="pre_profile_image" id="pre_profile_image">
													</div>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-4">
													<div class="form-group">
														<label><?php echo e(('First Name')); ?></label>
														<input type="text" name="first_name" id="first_name" class="form-control first_name" value="<?php echo e($user->first_name); ?>">
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label><?php echo e(('Last Name')); ?></label>
														<input type="text" name="last_name" id="last_name" class="form-control last_name" value="<?php echo e($user->last_name); ?>">
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label><?php echo e(('Email')); ?></label>
														<input type="email" name="email" id="email" class="form-control email" value="<?php echo e($user->email); ?>">
													</div>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-4">
													<div class="form-group">
														<label><?php echo e(('Phone')); ?></label>
														<input type="text" name="phone" id="phone" class="form-control phone" value="<?php echo e($user->phone); ?>">
													</div>
												</div>
											</div>
											<br>
											<strong>Address Info</strong>
											<hr>
											<div class="row">
												<div class="col-sm-3">
													<div class="form-group">
														<label><?php echo e('Country'); ?></label>
														<input type="text" name="country" id="country" class="form-control country" value="<?php echo e($user->country); ?>">
													</div>
												</div>
												<div class="col-sm-3">
													<div class="form-group">
														<label><?php echo e('State'); ?></label>
														<input type="text" name="state" id="state" class="form-control city" value="<?php echo e($user->state); ?>">
													</div>
												</div>
												<div class="col-sm-3">
													<div class="form-group">
														<label><?php echo e('City'); ?></label>
														<input type="text" name="city" id="city" class="form-control city" value="<?php echo e($user->city); ?>">
													</div>
												</div>
												<div class="col-sm-3">
													<div class="form-group">
														<label><?php echo e('Postal Code'); ?></label>
														<input type="text" name="postal_code" id="postal_code" class="form-control postal_code" value="<?php echo e($user->postal_code); ?>">
													</div>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-3">
													<div class="form-group">
														<label><?php echo e(('Address (Primary)')); ?></label>
														<input type="text" name="address_1" id="address_1" class="form-control address_1" value="<?php echo e($user->address_primary); ?>">
													</div>
												</div>
												<div class="col-sm-3">
													<div class="form-group">
														<label><?php echo e(('Address (Secondary)')); ?></label>
														<input type="text" name="address_2" id="address_2" class="form-control address_2" value="<?php echo e($user->address_secondary); ?>">
													</div>
												</div>
											</div>
											<br>
											<strong>Resume Info</strong>
											<hr>
											<div class="row">
												<div class="col-sm-4">
													<label>Resume Type</label>
													<select class="form-control" name="resume_type" id="resume_type">
														<option value="1" <?php echo e($user->resume_type == 1 ? 'selected' : ''); ?>>Private</option>
														<option value="0" <?php echo e($user->resume_type == 0 ? 'selected' : ''); ?>>Public</option>
													</select>
												</div>
												<div class="col-sm-4">
													<label>Desired Jop Title</label>
													<input type="text" name="desired_job_title" id="desired_job_title" class="form-control" value="<?php echo e($user->desired_job_title); ?>">
												</div>
												<div class="col-sm-4">
													<label>Desired Salary</label>
													<input type="text" name="desired_salary" id="desired_salary" class="form-control" value="<?php echo e($user->desired_salary); ?>">
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-4">
													<label>Desired Period</label>
													<select class="form-control" name="desired_period" id="desired_period">
														<option value="monhtly" <?php echo e($user->desired_period == 'monthly' ? 'selected' : ''); ?>>Monthly</option>
														<option value="yearly" <?php echo e($user->desired_period == 'yearly' ? 'selected' : ''); ?>>Yearly</option>
														<option value="daily" <?php echo e($user->desired_period == 'daily' ? 'selected' : ''); ?>>Daily</option>
													</select>
												</div>
												<div class="col-sm-4">
													<label>Desired Job Type</label>
													<select class="form-control" name="desired_jobtype" id="desired_jobtype">
														<option value="full_time" <?php echo e($user->desired_jobtype == 'full_time' ? 'selected' : ''); ?>>Full Time</option>
														<option value="part_time" <?php echo e($user->desired_jobtype == 'part_time' ? 'selected' : ''); ?>>Part Time</option>
													</select>
												</div>
												<div class="col-sm-4">
													<label>Resume Attachment</label>
													<input type="file" name="resume_attachment" id="resume_attachment" class="form-control">
													<input type="hidden" name="pre_resume_attachment" id="pre_resume_attachment" value="<?php echo e($user->resume_attachment); ?>">
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-12">
													<label><?php echo e(('Skill')); ?></label>
													<input type="text" name="skills" id="skills" class="form-control" value="<?php echo e($user->skills); ?>">
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-12">
													<label><?php echo e(('Headline')); ?></label>
													<textarea class="form-control" name="headline" id="headline" rows="4"><?php echo e($user->headline); ?></textarea>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-12">
													<label><?php echo e(('Summery')); ?></label>
													<textarea class="form-control" name="summery" id="summery" rows="4"><?php echo e($user->summery); ?></textarea>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-sm-12">
													<label><?php echo e(('Additional Information')); ?></label>
													<textarea class="form-control" name="addition_information" id="addition_information" rows="4"><?php echo e($user->addition_information); ?></textarea>
												</div>
											</div>                        
										</form>
										<br>
										<button class="btn btn-primary step_ahead" data-step="1" id="step_1">Save</button>
										<button class="btn btn-secondary" onclick="stepper.next()">Next</button>
									</div>

									<div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger">
										<div class="row">
											<div class="col-sm-12"> 
												<div class="row">
													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo e(('Level')); ?></label>
															<input type="text" id="edu_level" class="form-control">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo e(('Institude Name')); ?></label>
															<input type="text" id="edu_institude" class="form-control">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo e(('Field Name')); ?></label>
															<input type="text" id="edu_field" class="form-control">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo e(('Country')); ?></label>
															<input type="text" id="edu_country" class="form-control">
														</div>
													</div>
												</div>
												<br>
												<div class="row">
													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo e(('State')); ?></label>
															<input type="text" id="edu_state" class="form-control">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo e(('City')); ?></label>
															<input type="text" id="edu_city" class="form-control">
														</div>
													</div>
													<div class="col-sm-2">
														<div class="form-group">
															<label><?php echo e(('from')); ?></label>
															<input type="date" name="edu_start_date" id="education_start_date" class="form-control">
														</div>
													</div>
													<div class="col-sm-2">
														<div class="form-group">
															<label><?php echo e(('To')); ?></label>
															<input type="date" name="edu_end_date" id="education_end_start" class="form-control">
														</div>
													</div>
													<div class="col-sm-1">
														<button class="btn btn-primary add_education" style="text-align: center; margin-top: 24px" id="educations_add"><?php echo e(('Add')); ?></button>
													</div>
												</div>
												<br>
												<form action="#" method="post" id="education-frm">
													<?php echo csrf_field(); ?>
													<table class="table table-bordered">
														<thead>
															<tr>
																<th><?php echo e(('Level')); ?></th>
																<th><?php echo e(('Institude Name')); ?></th>
																<th><?php echo e(('Field Name')); ?></th>
																<th><?php echo e(('Country')); ?></th>
																<th><?php echo e(('State')); ?></th>
																<th><?php echo e(('City')); ?></th>
																<th><?php echo e(('From ')); ?></th>
																<th><?php echo e(('To ')); ?></th>
																<th><?php echo e(('Actions')); ?></th>
															</tr>
														</thead>
														<tbody class="education_tbody">
															<?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
																<tr class="row_<?php echo e($edu->id); ?>">
																		<input type="hidden" name="insert_update[]" value="1">
												 						<td><input type="text" class="form-control" name="level[]" value="<?php echo e($edu->level); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="institude[]" value="<?php echo e($edu->institute_name); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="field[]" value="<?php echo e($edu->field_name); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="country[]" value="<?php echo e($edu->country); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="state[]" value="<?php echo e($edu->state); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="city[]" value="<?php echo e($edu->city); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="from[]" value="<?php echo e($edu->period_from); ?>" readonly/></td>
												 						<td><input type="text" class="form-control" name="to[]" value="<?php echo e($edu->period_to); ?>" readonly/></td>
												 						<td><button class="btn btn-danger del-pre" data-id="<?php echo e($edu->id); ?>">X</button></td>
												 					</tr>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
														</tbody>
													</table>
													<input type="hidden" name="del_id" value="" id="del_ids">
												</form>
											</div>
										</div>
										<button class="btn btn-primary" onclick="stepper.previous()"><?php echo e(('Previous')); ?></button>
										<button class="btn btn-primary" onclick="stepper.next()"><?php echo e(('Next')); ?></button>
										<button class="btn btn-primary" id="save_education"><?php echo e(('Save And Next')); ?></button>
									</div>


									<div id="work-part" class="content" role="tabpanel" aria-labelledby="work-part-trigger">
										<div class="row">
											<div class="col-sm-12">
												<div class="row">
													<div class="col-sm-5">
														<div class="form-group">
															<label><?php echo e('Title'); ?></label>
															<input type="text" id="work_title" class="form-control">

														</div>
													</div>

													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo ('User.start_date')?></label>
															<input type="date" id="work_start_date" class="form-control">
														</div>
													</div>


													<div class="col-sm-3">
														<div class="form-group">
															<label><?php echo ('User.end_date')?></label>
															<input type="date" id="work_start_date" class="form-control">

														</div>
													</div>
													<div class="col-sm-1">
														<button class="btn btn-primary" style="margin-top: 31px" id="work_add">Add</button>
													</div>
												</div>
												<table class="table table-bordered">
													<thead>
														<tr>
															<th><?php echo ('User.title')?></th>
															<th><?php echo ('User.start_date')?></th>
															<th><?php echo ('User.end_date')?></th>
															<th><?php echo ('User.actions')?></th>
														</tr>
													</thead>
													<tbody class="work_tbody">
													</tbody>
												</table>
											</div>
										</div>
										<button class="btn btn-primary" onclick="stepper.previous()"><?php echo ('User.prevoius')?></button>
										<button type="submit" class="btn btn-primary step_ahead" data-step="4" id="step_4" onclick="stepper.next()"><?php echo ('User.complete')?></button>                            
									</div>
								</div>
							</div>

							<!-- /.card -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		 document.addEventListener('DOMContentLoaded', function () {
      window.stepper = new Stepper(document.querySelector('.bs-stepper'))
    });

		 $(document).ready(function(){
		 		$('#step_1').click(function(e){
		 			e.preventDefault();
		 			$('#step_1_form').submit();
		 		});
		 		$('#step_1_form').submit(function(e){
		 			e.preventDefault();
		 			var formData = new FormData(this);
		 			$.ajax({
		        type:'POST',
		        url: '<?php echo e(route("store_profile")); ?>',
		        data:formData,
		        cache:false,
		        contentType: false,
		        processData: false,
		        success:function(data){
		        	var converted = JSON.parse(data);
		        	if(converted.status == '1'){
		        		stepper.next();
		        	}else{
		        		alert('Something Wents Wrong');
		        	}
		        }
		      });
		 			console.log('Submitted');
		 		});

		 		$('#educations_add').click(function(){
		 			var level = $('#edu_level').val();
		 			var institude = $('#edu_institude').val();
		 			var field = $('#edu_field').val();
		 			var country = $('#edu_country').val();
		 			var state = $('#edu_state').val();
		 			var city = $('#edu_city').val();
		 			var from = $('#education_start_date').val();
		 			var to = $('#education_end_start').val();
		 			var html = '';
		 			if(level != '' && institude != '' && field != '' && from != '' && to != ''){
		 				html += `
		 					<tr>
			 					<input type="hidden" name="insert_update[]" value="0">
		 						<td><input type="text" class="form-control" name="level[]" value="${level}" readonly/></td>
		 						<td><input type="text" class="form-control" name="institude[]" value="${institude}" readonly/></td>
		 						<td><input type="text" class="form-control" name="field[]" value="${field}" readonly/></td>
		 						<td><input type="text" class="form-control" name="country[]" value="${country}" readonly/></td>
		 						<td><input type="text" class="form-control" name="state[]" value="${state}" readonly/></td>
		 						<td><input type="text" class="form-control" name="city[]" value="${city}" readonly/></td>
		 						<td><input type="text" class="form-control" name="from[]" value="${from}" readonly/></td>
		 						<td><input type="text" class="form-control" name="to[]" value="${to}" readonly/></td>
		 						<td><button class="btn btn-danger">X</button></td>
		 					</tr>
		 				`;
		 				$('.education_tbody').append(html);
		 			}
		 		});

		 		$('#save_education').click(function(e){
		 			e.preventDefault();
		 			$('#education-frm').submit();
		 		});

		 		$('#education-frm').submit(function(e){
					e.preventDefault();
					var formData = new FormData(this);
					$.ajax({
		        type:'POST',
		        url: '<?php echo e(route("store_education")); ?>',
		        data:formData,
		        cache:false,
		        contentType: false,
		        processData: false,
		        success:function(data){
		        	var converted = JSON.parse(data);
		        	if(converted.status == '1'){
		        		stepper.next();
		        	}else{
		        		alert('Something Wents Wrong');
		        	}
		        }
		      });
		 		});

		 		$('.del-pre').click(function(e){
		 			e.preventDefault();
		 			var edu_id = $(this).attr('data-id');
		 			var del_ids = $('#del_ids').val();
		 			var new_del_ids = del_ids+','+edu_id;
		 			$('#del_ids').val(new_del_ids);
		 			$(`.row_${edu_id}`).remove();
		 		})

		 });
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\moderntech\resources\views/auth/profile.blade.php ENDPATH**/ ?>